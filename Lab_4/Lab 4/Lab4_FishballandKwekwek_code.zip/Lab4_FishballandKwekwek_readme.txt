
Test Cases

2 * 19 =38
2 * 45 =90
2 * (-2) = -4
2 * 0 = 0

this is space for your input:
