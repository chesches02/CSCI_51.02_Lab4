//cppAssembly3.cpp
int dummy(int x){
    int ret = x * 27;
    return ret;
}